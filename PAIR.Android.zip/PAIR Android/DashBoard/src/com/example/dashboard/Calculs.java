package com.example.dashboard;

import android.util.Log;



//classe qui va r�cuperer les donn�e avec le protocole r�s0
public class Calculs extends Thread
{
	public int vitesse=0;
	public int direction=0;
	public Boolean Bactivate=false;
	public Boolean Reverse=false;
	public Boolean Line=false;
	public Boolean StopStart=false;
	public Boolean AutoMan=false;
	
	private void Calculs()
	{
		
	}
	
	public void run() 
	{
		int i=0;
		int j=-45;
		while(true)
		{
			vitesse=i;
			direction=j;
			j++;
			i++;
			if(i==35)
			{
				i=0;
				Bactivate=!Bactivate;
				Reverse=!Reverse;
				Line=!Line;
			}
			//String machin=Integer.toString(i);
			//Log.d("Calcul",machin);
			if(j==46)
			{
				j=-45;
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public Boolean getReverse() {
		return Reverse;
	}

	public void setReverse(Boolean reverse) {
		Reverse = reverse;
	}

	public int getVitesse() {
		return vitesse;
	}
	public void setVitesse(int vitesse) {
		this.vitesse = vitesse;
	}
	public int getDirection() {
		return direction;
	}
	public void setDirection(int direction) {
		this.direction = direction;
	}
	
	public Boolean getBactivate() {
		return Bactivate;
	}

	public void setBactivate(Boolean bactivate) {
		Bactivate = bactivate;
	}
	
	public Boolean getLine() {
		return Line;
	}

	public void setLine(Boolean line) {
		Line = line;
	}
	
	public Boolean getStopStart() {
		return StopStart;
	}

	public void setStopStart(Boolean stopStart) {
		StopStart = stopStart;
	}
	
	public Boolean getAutoMan() {
		return AutoMan;
	}

	public void setAutoMan(Boolean autoMan) {
		AutoMan = autoMan;
	}
	
}
