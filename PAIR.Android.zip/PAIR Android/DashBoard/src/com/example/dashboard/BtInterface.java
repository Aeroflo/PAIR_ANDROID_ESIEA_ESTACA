package com.example.dashboard;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.sax.StartElementListener;



public class BtInterface {
	
	
	private BluetoothDevice device = null;
	private BluetoothSocket socket = null;
	private InputStream receiveStream = null;
	private OutputStream sendStream = null;
	
	private ReceiverThread receiverThread;
	
	public BtInterface(Handler hstatus, Handler h)//constructeur
	{
		Set<BluetoothDevice> setpairedDevices = BluetoothAdapter.getDefaultAdapter().getBondedDevices();
		BluetoothDevice[] pairedDevices = (BluetoothDevice[]) setpairedDevices.toArray(new BluetoothDevice[setpairedDevices.size()]);
		
	}
	
	public void sendData(String Datas)
	{
		sendData(Datas, false);
	}
	
	//surcharge
	
	public void sendData(String Datas, boolean deleteScheduledData )
	{
		try {
			sendStream.write(Datas.getBytes());
	        sendStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	//connecter 
	
	public void connect() {
		new Thread() {
			@Override public void run() {
				try {
					socket.connect();
					
					//Message msg = handler.obtainMessage();
					//msg.arg1 = 1;
	               // handler.sendMessage(msg);
	                
					receiverThread.start();
					
				} catch (IOException e) {
					//Log.v("N", "Connection Failed : "+e.getMessage());
					e.printStackTrace();
				}
			}
		}.start();
	}
	
	private class ReceiverThread extends Thread
	{
		

	}


}