package com.example.dashboard;

import android.R.integer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MotionEvent;
import android.widget.Toast;

public class MainActivity extends Activity {
 
	public int Hdevice; //definir la taille du device
	public int Wdevice;
	
	//mettre en place le bluetooth
	private BtInterface BlueT = null;
	private long lastTime = 0;
	
	//creation des handler
	
	final Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            String data = msg.getData().getString("receivedData");
            
            long t = System.currentTimeMillis();
            if(t-lastTime > 100) 
            {// Pour �viter que les messages soit coup�s
                //logview.append("\n");
				lastTime = System.currentTimeMillis();
			}
            //logview.append(data);
        }
    };
    
    final Handler handlerStatus = new Handler() {
        public void handleMessage(Message msg) {
            int co = msg.arg1;
            if(co == 1) {
            	//logview.append("Connected\n");
            } else if(co == 2) {
            	//logview.append("Disconnected\n");
            }
        }
    };
    @Override
   
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Log.d("oncreate","hello" );
        
        //creation de la classe bluetooth
        //BlueT= new BtInterface(handlerStatus,handler);
        
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        Hdevice=metrics.heightPixels;
        Wdevice=metrics.widthPixels;
        
        String SHD= Integer.toString(Hdevice);
        String SWD= Integer.toString(Wdevice);
        
        //Log.d("main H",SHD);
       // Log.d("main W",SWD);
        		
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
    	int x=(int)event.getX();
    	int y=(int)event.getY();
    	String msg="";
    	switch(event.getAction()){
    	case MotionEvent.ACTION_DOWN:
    		//msg="Action: DOWN";
    		
    		if((x>=30)&&(x<=330)&&(y>=610)&&(y<=710))//bouton stop or start
    		{
    			Boolean etatdustop= Panel_image.calculs.getStopStart();
    			Panel_image.calculs.setStopStart(!etatdustop);
    		}
    		
    		if((x>=950)&&(x<=1250)&&(y>=610)&&(y<=710)) //bouton manuel ou auto
    		{
    			Boolean etatduauto= Panel_image.calculs.getAutoMan();
    			Panel_image.calculs.setAutoMan(!etatduauto);
    		}
    		
    		if((x>=30)&&(x<=330)&&(y>=500)&&(y<=600)) //bouton connection bluetooth
    		{
    			
    			//Boolean etatduauto= Panel_image.calculs.getAutoMan();
    			//Panel_image.calculs.setAutoMan(!etatduauto);
    			//BlueT.connect();
    			msg="connection blue";
    		}
    		break;
 
    	case MotionEvent.ACTION_UP:
    		//msg="Action: UP";
    		break;
 
    	case MotionEvent.ACTION_MOVE:
    		//msg="Action: MOVE";
    		break;
 
    	}
 
    	Toast.makeText(this, "Action : "+msg+" : Coordonn�es : X "+x+" : Y "+y, Toast.LENGTH_SHORT).show();
 
    	return super.onTouchEvent(event);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
