package com.example.dashboard;

import android.annotation.SuppressLint;
import android.graphics.Canvas;
import android.view.SurfaceHolder;

@SuppressLint("WrongCall") public class CanvasThread extends Thread {
	
	private SurfaceHolder _surfaceHolder;
    private Panel_image _panel;
    private boolean _run = false;

    public CanvasThread(SurfaceHolder surfaceHolder, Panel_image panel) {
        _surfaceHolder = surfaceHolder;
        _panel = panel;
    }
    
    public void setRunning(boolean run) {
        _run = run;
    }

    @Override
    public void run() {
        Canvas c;
        int i=20; 
        c = null;
        while (_run) {
           
            try {
            	
                c = _surfaceHolder.lockCanvas(null);
                synchronized (_surfaceHolder) { 
                   _panel.onDraw(c, 0);
               }
            } catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
                // do this in a finally so that if an exception is thrown
                // during the above, we don't leave the Surface in an
                // inconsistent state
                if (c != null) {
                    _surfaceHolder.unlockCanvasAndPost(c);
                }
            }
        }
    }

}
