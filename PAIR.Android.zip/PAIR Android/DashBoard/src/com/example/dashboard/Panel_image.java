package com.example.dashboard;

import java.io.IOException;
import java.io.InputStream;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.Rect;
import android.provider.ContactsContract.CommonDataKinds.Event;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;

public class Panel_image extends SurfaceView implements SurfaceHolder.Callback
{

	private Paint circlepaint;
	private Paint rectpaint;
	private Path triangle;
	private CanvasThread canvasthread;
	public static Calculs calculs;
	
	Bitmap EtatCoff;	 //image connection off
	Bitmap EtatCon;		 //image connection on
	Bitmap Reverseon;	 //marche arriere activ�
	Bitmap Reverseoff;	 //marche arri�re desactiv�
	Bitmap Linedesteted; //line d�tect�
	Bitmap LineNo;		 //line pas d�tect�
	Bitmap Stop;		 //stopper les machines
	Bitmap Start;		 //en avant les machines !!!
	Bitmap Automatique;	 //active le mode auto
	Bitmap Manuel;		 //active le mode manuel
	Bitmap Connection;	 //active une connection bluetooth
	
	
	
	public Panel_image(Context context, AttributeSet attrs) 
	{
		super(context, attrs); 
		// TODO Auto-generated constructor stub
	    getHolder().addCallback(this);
	    canvasthread = new CanvasThread(getHolder(), this);
	    setFocusable(true);
	    Log.d("panel","cr�ation" );
	    circlepaint=new Paint();
	    rectpaint =new Paint();
	    calculs = new Calculs();
	    
	    calculs.start();
	    triangle =new Path();
	    
	    //on charge toute les images car elle prenne du temps de calculs
	    
		InputStream inputStream = null;
		//Bitmap EtatCoff = null;
		try 
		{
			AssetManager assetManager = context.getAssets();
			
			inputStream = assetManager.open("EtatCOFF.png");
			EtatCoff = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("EtatCON.png");
			EtatCon = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("ROFF.png");
			Reverseoff = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("RON.png");
			Reverseon = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("Lineon.png");
			Linedesteted = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("Lineoff.png");
			LineNo = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("stop.png");
			Stop = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("go.png");
			Start = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("man.png");
			Manuel = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("auto.png");
			Automatique = BitmapFactory.decodeStream(inputStream);
			inputStream = assetManager.open("connect.png");
			Connection = BitmapFactory.decodeStream(inputStream);
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			//e.printStackTrace();
			Log.e("catch", "Les fichiers n'ont pas �t� trouv�s !");
		}
		finally
		{
        	try 
        	{
        		if (inputStream != null)
				inputStream.close();
			} 
        	catch (IOException e)
        	{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
	   
		
	}

	
	public void onDraw(Canvas canvas, int i)
	{
		//this.onTouchEvent(event);
		//on d�sine la fen�tre
		//attention i en argument devra �tre retir� car elle corespond � la position de l'aiguille du compteur
		Paint paint = new Paint();
		int isRusty = 1;
		int radiusspeed; //rayon du cercle
		int radiusdirection;
		
		int CHSpeedCpt =(int)(canvas.getHeight()/2);
		int CWSpeedCpt =(int)(canvas.getWidth()/2);
		
		int CHdirection =(int)(canvas.getHeight()/3);
		int CWdirection =(int)(canvas.getWidth()/2);
		
		Bitmap BlueState = null;
		Bitmap ReverseState=null;
		Bitmap LineState=null;
		Bitmap Stopstate=null;
		Bitmap AutoState=null;
		
		//Graphics 
		//String CHD= Integer.toString(CH);
        //String CWD= Integer.toString(CW);
        
        //Log.d("canvas H",CHD);
        //Log.d("canvas W",CWD);
        //ajouter les images qui permettent � l'utilisateur d'avoir les information
		
		//�tat de connection du bluetooth;
		
		//si inactive
		if(calculs.getBactivate()==false)
		{
			BlueState=EtatCoff;
		}
		else //alors active
		{
			BlueState=EtatCon;
		}
		Bitmap EtatBrezides= Bitmap.createScaledBitmap(BlueState, 100, 100, true);
		canvas.drawBitmap(EtatBrezides, CWSpeedCpt-260, 10, null);
		
		//marche arri�re?
		if(calculs.getReverse()==false)
		{
			ReverseState=Reverseoff;
		}
		else
		{
			ReverseState=Reverseon;
		}
		
		Bitmap EtatRrezides= Bitmap.createScaledBitmap(ReverseState, 100, 100, true);
		canvas.drawBitmap(EtatRrezides,  CWSpeedCpt-260, 120, null);
		
		//ligne det�ct�
		if(calculs.getLine()==false)
		{
			LineState=LineNo;
		}
		else
		{
			LineState=Linedesteted;
		}
		
		Bitmap EtatLrezides= Bitmap.createScaledBitmap(LineState,  100, 100, true);
		canvas.drawBitmap(EtatLrezides, CWSpeedCpt+160, 10, null);
		
		//Stop ou marche
		if(calculs.getStopStart()==false)
		{
			Stopstate=Stop;
		}
		else
		{
			Stopstate=Start;
		}
		
		Bitmap StartorStop= Bitmap.createScaledBitmap(Stopstate,  300, 100, true);
		canvas.drawBitmap(StartorStop, 10,canvas.getHeight()-100 , null);
		
		//Mode manuel ou automatique
		if(calculs.getAutoMan()==false)
		{
			AutoState=Automatique;
		}
		else
		{
			AutoState=Manuel;
		}
				
		Bitmap AutoorMan= Bitmap.createScaledBitmap(AutoState,  300, 100, true);
		canvas.drawBitmap(AutoorMan, canvas.getWidth()-310,canvas.getHeight()-100 , null);
		
		//connection au bluetooth bouton
		Bitmap ConnectionBT= Bitmap.createScaledBitmap(Connection,  300, 100, true);
		canvas.drawBitmap(ConnectionBT, 10,canvas.getHeight()-210 , null);
		
		radiusspeed=(int)(canvas.getWidth()/6); //centre du cercle speed
		radiusdirection=(int)(canvas.getWidth()/7);//centre du cercle rotation
		
	
		//desiner le cercle de la rotation + aiguille etla normale du compteur d'angle roue
		circlepaint.setColor(Color.WHITE);
		canvas.drawCircle(CWdirection,CHdirection, radiusdirection, circlepaint);
		canvas.rotate(90, CWdirection, CHdirection);
		circlepaint.setColor(Color.BLUE);
		canvas.drawLine(CWdirection,CHdirection, CWdirection-radiusdirection, CHdirection,circlepaint);
		canvas.rotate(0.5f, CWdirection, CHdirection);
		canvas.drawLine(CWdirection,CHdirection, CWdirection-radiusdirection, CHdirection,circlepaint);
		canvas.rotate(-0.5f, CWdirection, CHdirection);
		canvas.drawLine(CWdirection,CHdirection, CWdirection-radiusdirection, CHdirection,circlepaint);
		canvas.rotate(-90, CWdirection, CHdirection);
		
		canvas.save();
		
		//dessin de l'aiguilleen rouge
		rectpaint.setColor(Color.RED);
		triangle.reset();
		triangle.moveTo(CWdirection,CHdirection-radiusdirection );
		triangle.lineTo(CWdirection-10,CHdirection);
		triangle.lineTo(CWdirection +10,CHdirection);
		canvas.rotate((calculs.getDirection()),CWdirection,CHdirection);
		canvas.drawPath(triangle, rectpaint);
		canvas.rotate(-(calculs.getDirection()),CWdirection,CHdirection);
		canvas.save();
		
		
		//desiner le cercle du compteur de vitesse
		circlepaint.setColor(Color.BLUE);
		canvas.drawCircle(CWSpeedCpt, CHSpeedCpt, radiusspeed, circlepaint);
		canvas.save();
		
		//desiner les ligne du compteur
		circlepaint.setARGB(255, 255, 255, 0);
		canvas.rotate(-80,CWSpeedCpt,CHSpeedCpt);
		for(i=0;i<=20;i++)
		{
			if(i>=16)
			{
				circlepaint.setARGB(255, 255, 255-i*50, 0);
			}
			canvas.rotate(10,CWSpeedCpt,CHSpeedCpt);
			canvas.drawLine(CWSpeedCpt-radiusspeed, CHSpeedCpt, CWSpeedCpt, CHSpeedCpt, circlepaint);
			canvas.rotate(0.4f,CWSpeedCpt,CHSpeedCpt);
			canvas.drawLine(CWSpeedCpt-radiusspeed, CHSpeedCpt, CWSpeedCpt, CHSpeedCpt, circlepaint);
			canvas.rotate(-0.4f,CWSpeedCpt,CHSpeedCpt);
			canvas.drawLine(CWSpeedCpt-radiusspeed, CHSpeedCpt, CWSpeedCpt, CHSpeedCpt, circlepaint);
			canvas.save();	
		}
		
		//d�siner l'�guille en fonction de son pourcentage 
		canvas.rotate(-220,CWSpeedCpt,CHSpeedCpt);
		canvas.save();
		
		rectpaint.setColor(Color.WHITE);
		triangle.reset();
		triangle.moveTo(CWSpeedCpt,CHSpeedCpt-radiusspeed+5 );
		triangle.lineTo(CWSpeedCpt-40,CHSpeedCpt);
		triangle.lineTo(CWSpeedCpt +40,CHSpeedCpt);
		
		canvas.rotate(((calculs.getVitesse()*2)-70),CWSpeedCpt,CHSpeedCpt);
		canvas.drawPath(triangle, rectpaint);
		canvas.save();
		canvas.rotate(-(((calculs.getVitesse()*2)-70)),CWSpeedCpt,CHSpeedCpt);
		
		//une fois qu'on a desinn� les aiguilles on dessine un cercle noir d�co
		circlepaint.setColor(Color.BLACK);
		canvas.drawCircle(CWSpeedCpt, CHSpeedCpt, radiusspeed-45, circlepaint);
		
		//dessiner les chiffres
		circlepaint.setARGB(255, 255, 255, 0);
		circlepaint.setTextSize(20);
		canvas.save();
		
		
		for(i=0;i<=10;i++)
		{
			if(i>=8)
			{
				circlepaint.setARGB(255, 255, 255-i*75, 0);
			}
			canvas.rotate(20,CWSpeedCpt,CHSpeedCpt);
			String num= Integer.toString(i*10);
			canvas.drawText(num, CWSpeedCpt-radiusspeed+50 , CHSpeedCpt, circlepaint);
			canvas.save();
		}
		canvas.save();
		
		canvas.rotate(360-130,CWSpeedCpt,CHSpeedCpt);//il faut remmetre en ordre ce gros merdier
		canvas.save();
		
		circlepaint.setARGB(255, 255, 255, 0);
		circlepaint.setTextSize(25);
		//on affiche la vitesse et la rotation des roues dans le cadran au milieu, pour meilleurs visibilit�
		String affnumber00 = Integer.toString(calculs.getVitesse());
		String affnumber01 = "Vit (en %): ";
		//affnumber01.concat(affnumber00);
		canvas.drawText(affnumber01.concat(affnumber00), CWSpeedCpt-80, CHSpeedCpt, circlepaint);
		
		String affnumber10 = Integer.toString(calculs.getDirection());
		String affnumber11 = "Braq (en deg): ";
		canvas.drawText(affnumber11.concat(affnumber10), CWSpeedCpt-80, CHSpeedCpt+40, circlepaint);
		
	}
	
	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}
	
	
	@Override
	public void surfaceCreated(SurfaceHolder holder) 
	{
		// TODO Auto-generated method stub
	    canvasthread.setRunning(true);
	    canvasthread.start();
	   
	}
	
	
	@Override
	public void surfaceDestroyed(SurfaceHolder holder)
	{
		// TODO Auto-generated method stub
		boolean retry = true;
		canvasthread.setRunning(false);
		while (retry) 
		{
			try 
			{
				canvasthread.join();
				retry = false;
			} 
			catch (InterruptedException e) 
			{
				// we will try it again and again...
			}
		}

	}
	
	

}
